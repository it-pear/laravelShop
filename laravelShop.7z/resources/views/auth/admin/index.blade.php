@extends('/layout/admin')
@section('title', 'дома')

@section('content')

<h2>Добро пожаловать Администратор</h2><hr>
<div class="table-responsive table-admin-products">

  <!-- <h3>Главная странциа</h3> -->

</div>


@endsection